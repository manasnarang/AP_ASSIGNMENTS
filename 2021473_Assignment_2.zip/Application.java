package com.example;

public interface Application {
    public static void StartApp(){};
}
