package com.example;

import com.example.FLIPZON;

public class Main {
    public static void main(String[] args) {
        Application app=new FLIPZON();
        FLIPZON.StartApp();
    }
}
